document.addEventListener('DOMContentLoaded', function () {
	/* 	Starts peity
		DOC: searches for the class and init. peity based on class
	 */
	$(".peity-pie").peity("pie");
	$('.peity-donut').peity('donut');
	$(".peity-line").peity("line");
	$(".peity-bar").peity("bar");
});